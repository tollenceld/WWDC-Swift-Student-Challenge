/*:
 # Welcome to stories of plant🌳!
 
 In this playground,you can learn:
 
 - 1⃣️The internal logic of various plants and trees in the growth process
 - 2⃣️Define the logic of plant growth yourself and create your own unique plant
 - 3⃣️The relationship between the law of plant growth and the law of animal growth

 In the next few pages (hopefully within 5 minutes), I will show you a mature deduction technique used in real-world botany.
 
 Before running the program ▶️, we can briefly understand the relevant knowledge📖.


 Take a snowflake❄️ as an example to understand the logic of fractals closely related to plant growth.
 
 A fractal is a self-similar object, which means that it recursively contains a smaller version of itself


 Click the run button at the bottom of the screen
 */
/*:
 You have just seen that the shape of the snowflake❄️ is perfected step by step.
 
  
  ![img](WhatAwaitsYou.png)
 
 
 In [Next Page](@next) you will see how to do this systematically!
*/



//#-hidden-code
import PlaygroundSupport
PlaygroundPage.current.liveView = EvolutionView(drawing: Fractals.snowflake)
//#-end-hidden-code


